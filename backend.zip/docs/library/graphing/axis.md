x y and z axes !!!!


