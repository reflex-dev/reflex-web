from .docpage import docpage
from .webpage import webpage
