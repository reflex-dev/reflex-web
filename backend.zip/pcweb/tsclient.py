# pcweb/tsclient.py
import typesense

client = typesense.Client({
  'api_key': 'rlZiN1JlveHUQhgjWbZTqG8BlYS6z1DK',
  'nodes': [{
    'host': '6xtoqsb1a4ip9u8gp-1.a1.typesense.net',
    'port': '443',
    'protocol': 'https'
  }],
  'connection_timeout_seconds': 2
})

print("client", client)